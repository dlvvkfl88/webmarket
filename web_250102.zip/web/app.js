const express = require('express');
const app = express();
const path = require('path');

const PORT = 3000;

// EJS 설정
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// 정적 파일 경로 설정
app.use(express.static(path.join(__dirname, 'public')));

// 로그인 페이지 라우트 설정
app.get(['/', '/login'], (req, res) => {
    res.render('login'); 
});

// 메인페이지
app.get(['/index'], (req, res) => {
    res.render('index'); 
});

// 재사용 마켓 메인페이지
app.get(['/reusable_market'], (req, res) => {
    res.render('reusable_market'); 
});

// 반납 신청 목록 페이지
app.get(['/return_application_list'], (req, res) => {
    res.render('return_application_list'); 
});

// 반납 신청서 작성 팝업창 (교수님)
app.get(['/return_applicationPopup'], (req, res) => {
    res.render('return_applicationPopup'); 
});

// 반납 신청서 작성 팝업창 (직원)
app.get(['/approval_applicationPopup'], (req, res) => {
    res.render('approval_applicationPopup'); 
});

// 등록 물품 관리
app.get(['/registration_list'], (req, res) => {
    res.render('registration_list'); 
});
// 신청자 확인 팝업
app.get(['/applicant_checkPopup'], (req, res) => {
    res.render('applicant_checkPopup'); 
});


// 등록 물품 관리
app.get(['/applications_list'], (req, res) => {
    res.render('applications_list'); 
});
// 등록자 확인 팝업업
app.get(['/registrar_checkPopup'], (req, res) => {
    res.render('registrar_checkPopup'); 
});


// 양도 완료된 물품 목록
app.get(['/transactions_list'], (req, res) => {
    res.render('transactions_list'); 
});

// 결재함
app.get(['/approval_box'], (req, res) => {
    res.render('approval_box'); 
});

// 결재 요청 신청자 상세보기 팝업
app.get(['/approval_applicationPopup02'], (req, res) => {
    res.render('approval_applicationPopup02'); 
});

// 결재자 (중간 결재자) 팝업
app.get(['/approval_applicationPopup03'], (req, res) => {
    res.render('approval_applicationPopup03'); 
});

// 결재자 (최종 결재자) 팝업
app.get(['/approval_applicationPopup04'], (req, res) => {
    res.render('approval_applicationPopup04'); 
});

// test
app.get(['/test'], (req, res) => {
    res.render('test'); 
});
// test popup
app.get(['/CheckMyItems_Popup'], (req, res) => {
    res.render('CheckMyItems_Popup'); 
});




app.listen(PORT, () => {
    console.log(`서버가 http://localhost:${PORT} 에서 실행 중입니다.`);
});
