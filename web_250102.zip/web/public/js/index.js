document.addEventListener('DOMContentLoaded', function () {

    //gnb 메뉴 클릭 이벤트
    const gnb = document.querySelectorAll('.gnb > ul > li > a'); //gnb 메뉴
    const AllSubMenu = document.querySelectorAll('.sub_menu'); //모든 하위 매뉴

    if (gnb.length > 0) {
        gnb.forEach(menu => {
            menu.addEventListener('click', function (e) {
                e.preventDefault(); // 기본 링크 동작 방지

                const subMenu = this.nextElementSibling; // 현재 클릭된 메뉴의 하위 메뉴

                // 모든 하위 메뉴 닫기
                AllSubMenu.forEach(menu => {
                    if (menu !== subMenu) {
                        menu.classList.remove('click');
                    }
                });

                // 클릭된 하위 메뉴 열기/닫기
                if (subMenu) {
                    subMenu.classList.toggle('click');
                }
            });
        });

        // 문서 외부 클릭 시 모든 하위 메뉴 닫기
        document.addEventListener('click', function (e) {
            if (!e.target.closest('.gnb')) {
                AllSubMenu.forEach(menu => menu.classList.remove('click'));
            }
        });
    }

    // 메인페이지 슬라이드
    const sliderWrap = document.querySelector('.slider_wrap');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    const slides = document.querySelectorAll('.slide');

    if (sliderWrap && prevBtn && nextBtn && slides.length > 0) {
        const totalSlides = slides.length;
        let currentIndex = 0; // 현재 슬라이드 위치
        const slidesToShow = 5; // 한 화면에 보이는 슬라이드 개수

        // 슬라이드 이동 함수
        function moveSlider() {
            const slideWidth = slides[0].offsetWidth; // 슬라이드 한 개의 너비
            sliderWrap.style.transform = `translateX(-${currentIndex * slideWidth}px)`;

            // 버튼 비활성화 설정
            prevBtn.classList.toggle('disabled', currentIndex === 0);
            nextBtn.classList.toggle('disabled', currentIndex >= totalSlides - slidesToShow);
        }

        // 다음 버튼 클릭 이벤트
        nextBtn.addEventListener('click', function () {
            if (currentIndex < totalSlides - slidesToShow) {
                currentIndex += slidesToShow; // 5개씩 이동
                if (currentIndex > totalSlides - slidesToShow) {
                    currentIndex = totalSlides - slidesToShow; // 범위 초과 방지
                }
                moveSlider();
            }
        });

        // 이전 버튼 클릭 이벤트
        prevBtn.addEventListener('click', function () {
            if (currentIndex > 0) {
                currentIndex -= slidesToShow; // 5개씩 이동
                if (currentIndex < 0) {
                    currentIndex = 0; // 범위 초과 방지
                }
                moveSlider();
            }
        });

        // 초기 버튼 상태 설정
        moveSlider();
    }

    //탭 전환 기능
    const tabs = document.querySelectorAll(".tab_menu_bar .tab");
    const tabContents = document.querySelectorAll("#tab_content .tab_item");

    if (tabs.length > 0 && tabContents.length > 0) {
        // 탭 변경 함수
        function changeTab(tabCategory) {
            // 모든 탭에서 active 클래스 제거
            tabs.forEach(tab => tab.classList.remove("active"));

            // 모든 콘텐츠 숨기기
            tabContents.forEach(content => {
                content.style.display = "none";
            });

            // 선택된 탭에 active 클래스 추가
            const selectedTab = document.getElementById(tabCategory + "Tab");
            if (selectedTab) {
                selectedTab.classList.add("active");
            }

            // 선택된 콘텐츠만 보이기
            tabContents.forEach(content => {
                if (content.getAttribute("data-category") === tabCategory) {
                    content.style.display = "flex";
                }
            });
        }

        // 탭 클릭 이벤트 등록
        tabs.forEach(tab => {
            tab.addEventListener("click", function () {
                const tabCategory = this.id.replace("Tab", ""); // 탭 ID에서 카테고리 추출
                changeTab(tabCategory);
            });
        });

        // 초기 상태: "전체" 탭 활성화
        changeTab("all");
    }

    //등록한 물품 슬라이드
    document.querySelector('.slide_down01').addEventListener('click', function() {
        const ol01 = document.querySelector('.sl_ol01');
        const items = ol01.querySelectorAll('li');
        
        // 첫 번째 아이템을 복제하여 마지막에 추가
        const firstItem = items[0].cloneNode(true);
        
        setTimeout(() => {
            // 첫 번째 아이템 제거
            ol01.removeChild(items[0]);
            // 복제한 아이템을 마지막에 추가
            ol01.appendChild(firstItem);
            // 나머지 아이템들 위치 조정
            items.forEach(item => {
                item.style.transition = 'none';
                item.style.transform = 'translateY(0)';
            });
        }, 0);
    });

    //신청한 물품 슬라이드
    document.querySelector('.slide_down02').addEventListener('click', function() {
        const ol02 = document.querySelector('.sl_ol02');
        const items = ol02.querySelectorAll('li');
        
        // 첫 번째 아이템을 복제하여 마지막에 추가
        const firstItem = items[0].cloneNode(true);
        
        setTimeout(() => {
            // 첫 번째 아이템 제거
            ol02.removeChild(items[0]);
            // 복제한 아이템을 마지막에 추가
            ol02.appendChild(firstItem);
            
            // 보이는 아이템 개수 조절
            const newItems = ol02.querySelectorAll('li');
            newItems.forEach((item, index) => {
                item.style.transition = 'none';
                item.style.transform = 'translateY(0)';
                if(index < 2) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }, 0);
    });

});